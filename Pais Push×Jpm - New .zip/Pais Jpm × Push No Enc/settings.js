require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285710115864"
global.namaowner = "Pais"

//======== Setting Bot & Link ========//
global.namabot = "Pais Push×Jpm" 
global.namabot2 = "Pais Push×Jpm"
global.foother = "© PAIS MARKETPLACE - 2024"
global.thumle = "https://telegra.ph/file/1c64a998060cf87f1fb51.jpg"
global.linkgc = 'https://chat.whatsapp.com/G6ff6LdD3zsITPF7PufiE1'
global.marketplace = "https://chat.whatsapp.com/JSsmIJlaeP8HrY3WiCtaM8"
global.linkyt = 'https://www.youtube.com/@Pais-MD_Official'
global.linktele = "https://t.me/paisofficial"
global.packname = "Created By pais"
global.author = "pais"
global.ror = "case"
global.online = "Online"
global.author = "pais"

//========== Setting Foto ===========//
global.imgmenu = fs.readFileSync("./media/Menu.jpg")

//========== Setting Key ==========//
global.keylogin = "paisv82009"
//Gak ada key ya? pasti dapet dari free wkwkwk
//buy Pais V8 Ori? Hub 6285710115864
//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = true
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 3500

//========= Setting Url Foto =========//
//Lihat Di Folder Media!

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://paismarket.paismarketplace.biz.id"
global.apikey = "ptla_0CR0bWt9AjEdUfsK1mrS4l2y3eSdXEWqC5SYznt3hgv"
global.capikey = "ptlc_NGskLmiHrmXdmY1lOth5smXtKb9vif5ChcF0EKm68Nj"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "085285797378"
global.gopay = "085285797378"
global.ovo = false
global.qris = fs.readFileSync("./media/qris.jpg")
                             
//=========== Api Domain ===========//
global.zone1 = "c2047082b74a80e5be03959bad59592a"
global.apitoken1 = "Nop2RDsy0Uyh1WHE17CC59aEhen-ZA61MWNrAqVl"
global.tld1 = "digitalserver.biz.id"

//========== Api Domain 2 ==========//
global.zone2 = "a476ffcf9243c44a02220f184da527e8";
global.apitoken2 = "RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ";
global.tld2 = "mypanell.biz.id";
//========== Api Domain 3 ==========//
global.zone3 = "5f4a582dd80c518fb2c7a425256fb491";
global.apitoken3 = "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby";
global.tld3 = "tokopanellku.my.id";
//========== Api Domain 4 ==========//
global.zone4 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken4 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld4 = "panellstore.net";
global.linksaluran = "https://whatsapp.com/channel/0029Vak8BtXDTkK2pVnSX33D"
global.idtextsd =  "120363318655866794@newsletter"
//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Bang ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})