 ⇘ ʅιʂƚ ʝρɱ αɳƚι σƙҽρ ⇙

5𝙆 : 40 𝙈𝙀𝙈𝘽𝙀𝙍
10𝙆 : 80 𝙈𝙀𝙈𝘽𝙀𝙍
20𝙆 : 160 𝙈𝙀𝙈𝘽𝙀𝙍
40𝙆 : 350 𝙈𝙀𝙈𝘽𝙀𝙍
60𝙆 : 300 𝙈𝙀𝙈𝘽𝙀𝙍
80𝙆 : 400 𝙈𝙀𝙈𝘽𝙀𝙍
100𝙆 : 500 𝙈𝙀𝙈𝘽𝙀𝙍
120𝙆 : 600 𝙈𝙀𝙈𝘽𝙀𝙍
140𝙆 : 700 𝙈𝙀𝙈𝘽𝙀𝙍
160𝙆 : 800 𝙈𝙀𝙈𝘽𝙀𝙍
180𝙆 : 900 𝙈𝙀𝙈𝘽𝙀𝙍
250𝙆 : 𝙁𝙐𝙇𝙇 1025 𝙈𝙀𝙈𝘽𝙀𝙍

*Testi Jpm pais*
https://whatsapp.com/channel/0029VaXAdgi6GcGBT6rxsW3j

*PAYMENT 𝗣𝗮𝗶𝘀: GOPAY, DANA, OVO, QRIS*

*S&K*:
*• GRUB WAJIB DI TUTUP*
*• WAJIB AKTIFIN PERMINTAAN BERGABUNG DI GRUB*
*• WAJIB ADMININ NO REKBER ( 𝗣𝗮𝗶𝘀 )*